import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InterviewBotComponent } from './interview-bot.component';

describe('InterviewBotComponent', () => {
  let component: InterviewBotComponent;
  let fixture: ComponentFixture<InterviewBotComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [InterviewBotComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(InterviewBotComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
