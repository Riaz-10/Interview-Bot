import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
// import { ActivatedRoute } from '@angular/router';
import { InterviewBotService } from '../service/interview-bot.service';
// import { VoiceRecognitionService } from '../service/voice-recognition.service';

@Component({
  selector: 'app-interview-bot',
  standalone: true,
  imports: [FormsModule, CommonModule, HttpClientModule, MatIconModule],
  templateUrl: './interview-bot.component.html',
  styleUrl: './interview-bot.component.css',
})
export class InterviewBotComponent {
  message: string = '';
  chats: { role: string; content: string }[] = [];
  recognition: any;
  listening = true;

  constructor(private interviewBotService: InterviewBotService) {
    if (typeof window !== 'undefined' && 'webkitSpeechRecognition' in window) {
      this.recognition = new (window as any).webkitSpeechRecognition();
      this.recognition.lang = 'en-US';
      this.recognition.continuous = true;
      this.recognition.interimResults = true; // Enable interim results

      this.recognition.onresult = (event: any) => {
        let transcript = '';
        for (let i = event.resultIndex; i < event.results.length; i++) {
          if (event.results[i].isFinal) {
            transcript += event.results[i][0].transcript;
          } else {
            transcript += event.results[i][0].transcript + ' ';
          }
        }
        this.message = transcript.trim(); // Update message with interim results
        document
          .querySelector('textarea')
          ?.setAttribute('placeholder', this.message); // Clear textarea placeholder
        this.adjustTextareaHeight(); // Adjust textarea height
      };

      this.recognition.start(); // Start recognition
    }
  }
  ngOnDestroy() {
    if (this.recognition) {
      this.recognition.stop(); // Stop recognition when component is destroyed
    }
  }
  toggleListening(): void {
    if (this.listening) {
      this.recognition.stop(); // Stop recognition if currently listening
    } else {
      this.recognition.start(); // Start recognition if not listening
    }
    this.listening = !this.listening;
  }

  ngOnInit() {
    this.restorechatHistory();
  }

  chat(): void {
    document.querySelector('textarea')?.setAttribute('placeholder', ''); // Clear textarea placeholder
    if (!this.message.trim()) return;
    window.scrollTo(0, 1e10);

    const chats = [...this.chats];

    chats.push({ role: 'user', content: this.message.trim() });
    this.chats = chats;

    this.interviewBotService.chat(this.message.trim(), '1').subscribe(
      (data: any) => {
        chats.push({ role: 'bot', content: data.content });
        this.chats = chats;
        window.scrollTo(0, 1e10);
      },
      (error) => {
        console.log('error...', error);
      }
    );
    this.message = ''; // Clear message after sending
    this.adjustTextareaHeight(); // Adjust textarea height
  }

  adjustTextareaHeight(): void {
    const textarea = document.querySelector('textarea');
    if (textarea) {
      textarea.style.height = 'auto';
      textarea.style.height = textarea.scrollHeight + 'px';
    }
  }

  restorechatHistory() {
    // Add your logic here to restore chat history
  }
}
