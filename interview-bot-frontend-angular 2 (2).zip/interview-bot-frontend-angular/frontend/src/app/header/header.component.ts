import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { Router, RouterModule } from '@angular/router';

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [RouterModule, CommonModule],
  templateUrl: './header.component.html',
  styleUrl: './header.component.css',
})
export class HeaderComponent {
  isSessionKeyPresent: boolean = false;
  constructor(private router: Router) {
    if (typeof sessionStorage !== 'undefined') {
      this.isSessionKeyPresent = !!sessionStorage.getItem('username');
    }
  }

  logout() {
    sessionStorage.removeItem('username');
    this.isSessionKeyPresent = true;
    alert('Logout Successful.');
    this.router.navigateByUrl('/', { skipLocationChange: true }).then(() => {
      this.router.navigate(['login']);
    });
  }
}
