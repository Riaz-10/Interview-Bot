import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class InterviewBotService {
  private messageCount: number = 0;
  private chatHistory: { role: string; content: string; count: number }[] = [];

  constructor(private http: HttpClient) {}

  sendMessage(message: string): number {
    this.messageCount++;
    const count = this.messageCount;
    this.chatHistory.push({ role: 'user', content: message, count });
    return count;
  }

  getChatHistory(): { role: string; content: string; count: number }[] {
    return this.chatHistory;
  }

  chat(
    message: string,
    url: string
  ): Observable<{ role: string; content: string; count: number }> {
    console.log('service', message);
    const count = this.sendMessage(message);
    this.chatHistory.push({ role: 'bot', content: String(count), count });
    this.saveChatHistory();
    // try {
    //   this.saveChatHistory();
    //   return this.http.post<any>(`http://localhost:8000/${url}`, { message });
    // } catch (e) {
    //   console.log(e);
    // }
    return of({ role: 'bot', content: String(this.messageCount), count });
  }

  saveChatHistory(): void {
    const username: any = sessionStorage.getItem('username');
    localStorage.setItem(username, JSON.stringify(this.chatHistory));
  }
}