import { TestBed } from '@angular/core/testing';

import { InterviewBotService } from './interview-bot.service';

describe('InterviewBotService', () => {
  let service: InterviewBotService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(InterviewBotService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
