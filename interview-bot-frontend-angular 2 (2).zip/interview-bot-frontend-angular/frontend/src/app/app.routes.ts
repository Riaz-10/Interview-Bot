import { Routes } from '@angular/router';
import { InterviewBotComponent } from './interview-bot/interview-bot.component';

export const routes: Routes = [
  { path: 'interviewbot', component: InterviewBotComponent },
  { path: '**', component: InterviewBotComponent },
];
